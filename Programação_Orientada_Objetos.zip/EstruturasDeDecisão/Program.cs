﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EstruturasDeDecisão
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite sua idade:");
            UInt32 Idade = Convert.ToUInt32(Console.ReadLine());
            // Estruturas de decisão if(Se) else(Senão)
            if (Idade >= 18/* Condição booleana que pode ser true ou false */) // If Sempre precisa exisitr nas estruturas de decisão
            {
                Console.WriteLine("Você é maior de idade.");
            }
            else
            {
                Console.WriteLine("Você é menor de idade, menores de idade não são aceitos neste local. VAZA DAQUI!");
            }
            

            Console.WriteLine("Digite seu salário:");
            UInt32 Salario = Convert.ToUInt32(Console.ReadLine());
            //if...else...if
            if (Salario < 1000)
            {
                Console.WriteLine(" Você fez o L, por isto ta na merda ganhando menos que um estagiário.");
            }
            else if (Salario < 2000)
            {
                Console.WriteLine("Com esse salário o melhor a se fazer é verder cigarros do Paraguai.");
            }
            else if (Salario < 3000)
            {
                Console.WriteLine("Com esse salário o melhor a se fazer é vender água na rua.");
            }
            else if (Salario > 3000)
            {
                Console.WriteLine("Ta contando um troco cachorro");
            }
            else
            {
                Console.WriteLine("Parabéns, você não é um completo fracassado.");
            }

            Console.WriteLine("Precione uma tecla");
            char Tecla = Console.ReadKey(true).KeyChar;
            //switch (Comultador)
            switch (Tecla/*Variáveis*/)
            {
                case 'a' /*Valores*/: // Caso
                    Console.WriteLine("Você apertou a tecla A");
                    break; //Pare
                case 'b':
                    Console.WriteLine("Você apertou a tecla B");
                     break;
                default: // Padrão
                    Console.WriteLine("Você não apertou a tecla A nem a tecla B, eu não conheço essa tecla");
                    break;
            }

            Console.ReadKey();
        }
        
    }
}