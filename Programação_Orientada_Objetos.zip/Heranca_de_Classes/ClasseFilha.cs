﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heranca_de_Classes
{
    internal class ClasseFilha: ClasseMae // Herança de Classe
    {
        public string atributoFilha = "Atributo da Filha";
        public string PropriedadesFilha
        {
            get; set;
        }
        public void MetodoDaClasseFilha()
        {
            Console.WriteLine("Método da Classe Filha");
        }
        public ClasseFilha()
        {
            PropriedadesFilha = "Propriedade da Filha";
        }
    }
}
