﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heranca_de_Classes
{
    internal class ClasseMae
    {
        public string atributoMae = "Atributo da Mãe";
        public string PropriedadeMae
        {
            get; set;
        }
        public void MetodoDaClasseMae()
        {
             Console.WriteLine("Método da Classe Mãe");
        }
        public ClasseMae()
        {
            PropriedadeMae = "Propriedade da Mãe";
        }
    }
}
