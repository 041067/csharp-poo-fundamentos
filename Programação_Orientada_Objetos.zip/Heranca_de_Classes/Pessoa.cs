﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heranca_de_Classes
{
    internal abstract class Pessoa //Classe base abstrata que não pode ser instanciada
    {
        private string nome;
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        public void MostraNome()
        {
            Console.WriteLine("O nome da pessoa é: " + Nome);
        }
        public Pessoa(string pNome)
        {
            nome = pNome;
        }
    }
}
