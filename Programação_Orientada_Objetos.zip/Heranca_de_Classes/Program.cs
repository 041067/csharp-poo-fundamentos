﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heranca_de_Classes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*ClasseFilha objFilha = new ClasseFilha();
            objFilha.MetodoDaClasseFilha();
            objFilha.MetodoDaClasseMae();
            Console.WriteLine(objFilha.atributoMae);
            Console.WriteLine(objFilha.atributoFilha);*/

            Funcionario meuFuncionario = new Funcionario("José", 2500);
            meuFuncionario.MostraNome();
            meuFuncionario.MostraSalario();

            Console.ReadKey();
        }
    }
}
