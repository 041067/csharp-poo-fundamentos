﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Propriedades
//MODIFICADOR_DE_ACESSO TIPO NOME { get; set; }
//{
//      get { return ATRIBUTO; } - retorna o valor do atributo
//      set { ATRIBUTO = value; } - atribui o valor ao atributo
//}

namespace Propriedades
{
    public class numerosPrimos
    {
        //Atributo
        private static int numero;
        //Propriedade
        public static int Numero
        {
            get { return numero; }
            set { numero = value; }
        }
        //Método para verificar se o número é primo
        public static bool EhPrimo()
        {
            if (numero <= 1) return false;
            for (int i = 2; i <= Math.Sqrt(numero); i++)//Marth.Sqrt é raiz quadrada e For é um laço de repetição
            {
                if (numero % i == 0) return false ;
            }
            return true;
        }

    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite um número inteiro: ");
            numerosPrimos.Numero = int.Parse(Console.ReadLine());// Parce significa converter uma string em um número inteiro
            if (numerosPrimos.EhPrimo())
            {
                Console.WriteLine($"{numerosPrimos.Numero} é um número primo.");
            }
            else
            {
                Console.WriteLine($"{numerosPrimos.Numero} não é um número primo");
            }
            Console.ReadKey();
        }
    }
}
