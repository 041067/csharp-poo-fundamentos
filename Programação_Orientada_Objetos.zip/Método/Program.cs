﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Método
//MODIFICADOR_DE_ACESSO TIPO_DE_SAÌDA NOME_DO_MÈTODO(TIPO_PAR1 NOME_PAR1, TIPO_PAR2 NOME_PAR2 ...)
//{
//     CONTEÙDO_DO_MÈTODO
//     return VALOR_DE_SAÌDA
//}

namespace Método
{
    public class ContaBancaria
    {
        // Atributos
        private double Saldo;
        private string Senha;
        private string Titular;

        //Métodos
        public double Sacar(double pValorSacado, string pSenha)// Porque usar p? Ele serve para diferenciar o parâmetro do atributo
        {
            if (Senha == pSenha)
            {
                if (Saldo > pValorSacado)
                {
                    Saldo -= pValorSacado;
                    Console.WriteLine("O valor sacado foi de: " + pValorSacado);
                    return pValorSacado;
                }
                else
                {
                    Console.WriteLine("Saldo insuficiente");
                    return 0;
                }
            }
            else
            {
                Console.WriteLine("Senha incorreta");
                return 0;
            }
        }
        public void Depositar(double pValorDepositado)
        {
            Saldo += pValorDepositado;
            Console.WriteLine("O valor depositado foi de: " + pValorDepositado);
        }
        public void ConsultarSaldo(string pSenha)
        {
            if (Senha == pSenha)
            {
                Console.WriteLine("O saldo da conta é de: " + Saldo);
            }
            else
            {
                Console.WriteLine("Senha incorreta");
            }
        }
        // Construtor
        public ContaBancaria(string pTitular, string pSenha)
        {
            Titular = pTitular;
            Senha = pSenha;
            Saldo = 0;
            // Construtor é um método especial que é chamado quando um objeto é criado, ele não tem tipo de retorno e o nome é o mesmo da classe
            // Ele é usado para inicializar os atributos da classe
            // Pode ter parâmetros para inicializar os atributos com valores diferentes
            // Pode ter mais de um construtor, desde que tenham parâmetros diferentes (sobrecarga de construtores)
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            ContaBancaria contaDoSenai = new ContaBancaria("123456", "Senai São Paulo");
            /*
            ContaBancaria contaDoSenai = new ContaBancaria();
            contaDoSenai.Saldo = 0;
            contaDoSenai.Senha = "123456";
            contaDoSenai.Titular = "Senai";

            double valorSacado = contaDoSenai.Sacar(10, "123456");
            contaDoSenai.Depositar(1000);
            contaDoSenai.ConsultarSaldo("123456");
            valorSacado = contaDoSenai.Sacar(10, "123456");
            contaDoSenai.ConsultarSaldo("123456");
            Console.ReadKey();
            */
        }
    }
}
