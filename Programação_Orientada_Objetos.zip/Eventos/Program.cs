﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Eventos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Cozinha cozinhaHamburguer = new Cozinha();
            Cozinha cozinhaPizza = new Cozinha();

            TabletGarcom tabletMarcos = new TabletGarcom("Marcos", cozinhaHamburguer);
            TabletGarcom tabletCesar = new TabletGarcom("Cesar", cozinhaHamburguer);
            TabletGarcom tabletMaicon = new TabletGarcom("Maicon", cozinhaHamburguer);
            
            TabletGarcom tabletLarrisa = new TabletGarcom("Larissa", cozinhaPizza);
            TabletGarcom tabletBeatriz = new TabletGarcom("Beatriz", cozinhaPizza);
            TabletGarcom tabletAline = new TabletGarcom("Aline", cozinhaPizza);

            cozinhaHamburguer.EnviarMensagemPedidoPronto(1);

            cozinhaPizza.EnviarMensagemPedidoPronto(2);

            Console.ReadKey();   
        }
    }
}
