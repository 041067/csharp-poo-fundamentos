﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Eventos
{
    internal class TabletGarcom
    {
        private string nome;
        public void MostrarPedidoProntoNaCozinha(object fonte, EventArgsPedidoPronto e)
        {
            Console.WriteLine("O pedido " + e.NumeroPedido + " está promto! Por favor, vá até a cozinha para buscá-lo " + nome);
        }
        public TabletGarcom(string pNome, Cozinha pCozinha)
        {
            nome = pNome;
            pCozinha.MensagemPedidoProntoEvent += MostrarPedidoProntoNaCozinha;
        }
    }
}
