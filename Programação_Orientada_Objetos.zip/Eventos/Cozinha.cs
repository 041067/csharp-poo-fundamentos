﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Eventos
{
    internal class Cozinha
    {
        public delegate void MensagemPedidoProntoEventHandler(object fonte, EventArgsPedidoPronto e);
        public event MensagemPedidoProntoEventHandler MensagemPedidoProntoEvent;
        public void EnviarMensagemPedidoPronto(UInt32 pNumeroPedido)
        {
            if (MensagemPedidoProntoEvent != null)
            {
                EventArgsPedidoPronto e = new EventArgsPedidoPronto(pNumeroPedido);
                MensagemPedidoProntoEvent(this, e);
            }
        }
    }
}
