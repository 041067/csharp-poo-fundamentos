﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Variáveis
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int Idade; // Declaração da variável
            Idade = 29; // Atribuição de valor
            Console.WriteLine(Idade); // Uso da variável

            Idade = 30; // Alteração do valor da variável
            Console.WriteLine(Idade); //Exibição do novo valor da variável

            string NomeCompleto = "Sesi Brotas"; // Declaração de variável string
            Console.WriteLine(NomeCompleto);// Uso da variável string

            NomeCompleto = "Sesi Jaú"; // Alteração do valor da variável string
            Console.WriteLine(NomeCompleto);

            byte b = 255; // 1 byte (0 a 255)
            Console.WriteLine(b);

            var Salario = 10000; // Declaração de variável com var
            var NomeEmpresa = "Sesi Brotas";// Declaração de variável com var
            Console.WriteLine(Salario);
            Console.WriteLine(NomeEmpresa);

            DateTime DataNascimento = new DateTime(2025, 09, 09, 15, 29, 45); //Declarção da variável DateTime
            Console.WriteLine(DataNascimento.Year);
            Console.WriteLine(DataNascimento.Month);
            Console.WriteLine(DataNascimento.Day);
            Console.WriteLine(DataNascimento.Hour);
            Console.WriteLine(DataNascimento.Minute);
            Console.WriteLine(DataNascimento.Second);

            string NumeroDaCasa = "15"; // Declaração de variável string
            int NumeroDaCasaInt = Convert.ToInt32(NumeroDaCasa); // Conversão de string para int
            Console.WriteLine(NumeroDaCasaInt);

            Console.ReadKey();
        }
    }
}
