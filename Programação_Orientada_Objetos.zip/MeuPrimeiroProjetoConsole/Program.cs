﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeuPrimeiroProjetoConsole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.ReadLine();

            //È importante comentar o código para facilitar a compreensão do que o código faz
            // È representado pelo comentario de uma linha unica
            /*
             Esse é um comentario 
             de múltiplas linhas
             */
        }
    }
}
