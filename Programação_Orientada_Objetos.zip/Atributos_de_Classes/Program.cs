﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//MODIFICADOR_DE_ACESSO TIPO_DE_ATRIBUTO NOME_DO_ATRIBUTO
//Modificadores
//public - Todos podem acessar o nosso atributo/variável
//private - Somente nossa classe poderá acessar o nosso atributo/variável

namespace Atributos_de_Classes
{
    public class Carro
    {
        //Atributos
        public string marca;
        private double velocidade; // double = números com casas decimais

        //Métodos da classe para manipular o atributo privado
        public void Acelerar(double VelocidadeFinal)
        {
            velocidade = VelocidadeFinal;
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Carro meuCarro = new Carro();
            meuCarro.marca = "Ferrari";
            meuCarro.Acelerar (250);
            //meuCarro.velocidade = 300; // ERRO! Atributo privado
        }
    }
}