﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OperadoresLogicosEntreVariaveisBooleanas
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool var1 = true;//Verdadeiro
            bool var2 = false;//Falso

            //Operador de Negação (NOT) representado por "!"
            bool resultadoNegacao = !var1;
            Console.Write("A Negação de: " + var1 + " é " + resultadoNegacao);
            resultadoNegacao = !var2;
            Console.WriteLine("A Negação de: " + var2 + " é " + resultadoNegacao);

            //Operador OU (OR) representado por "|"
            bool resultadoOU = var1 | var1;
            Console.WriteLine("O resultado da operação OU entre " + var1 + " e " + var1 + " resulta em: " + resultadoOU);
            resultadoOU = var1 | var2;
            Console.WriteLine("O resultado da operação OU entre " + var1 + " e " + var2 + " resulta em: " + resultadoOU);
            resultadoOU = var2 | var2;
            Console.WriteLine("O resultado da operação OU entre " + var2 + " e " + var2 + " resulta em: " + resultadoOU);

            //Operador E (AND) representado por "&"
            bool resultadoE = var1 & var1;
            resultadoE = var1 & var1;
            Console.WriteLine("O resultado da operação & entre " + var1 + " e " + var1 + " resulta em: " + resultadoE);
            resultadoE = var1 & var2;
            Console.WriteLine("O resultado da operação & entre " + var1 + " e " + var2 + " resulta em: " + resultadoE);
            resultadoE = var2 & var2;
            Console.WriteLine("O resultado da operação & entre " + var2 + " e " + var2 + " resulta em: " + resultadoE);

            //Operador OU Exclusivo (XOR) representado por ^
            bool resultadoXOR = var1 ^ var1;
            resultadoXOR = var1 ^ var1;
            Console.WriteLine("O resultado da operação ^ entre " + var1 + " e " + var1 + " resulta em: " + resultadoXOR);
            resultadoXOR = var1 ^ var2;
            Console.WriteLine("O resultado da operação ^ entre " + var1 + " e " + var2 + " resulta em: " + resultadoXOR);
            resultadoXOR = var2 ^ var2;
            Console.WriteLine("O resultado da operação ^ entre " + var2 + " e " + var2 + " resulta em: " + resultadoXOR);

            Console.ReadKey();
        }
    }
}
