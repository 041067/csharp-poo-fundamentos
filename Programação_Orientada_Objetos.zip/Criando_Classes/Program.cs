﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//MODIFICADORES_DE_ACESSO class NOME_DA_CLASSE { }
// internal - Acesso limitado ao assembly atual
// public - Acesso sem restrições
// private - Acesso limitado à própria classe

namespace Criando_Classes
{
    internal class Carro_Internal
    {
        Carro_Public meuCarroPublic = new Carro_Public();
        //Carro_Private meuCarroPrivate = new Carro_Private();
        //Não é possível acessar a classe private por aqui!
    }
    public class Carro_Public
    {
        Carro_Internal meuCarroInternal = new Carro_Internal();
    }

    internal class Program
    {
        // private - Acesso limitado à própria classe
        private class Carro_Private
        {

        }
        static void Main(string[] args)
        {
            //NOME_DA_CLASSE NOME_DO_OBJETO = new NOME_DA_CLASSE(PARAMETROS);
            Carro_Internal meuCarroInternal = new Carro_Internal();
            Carro_Public meuCarroPublic = new Carro_Public();
            Carro_Private meuCarroPrivate = new Carro_Private();
        }
    }
}
