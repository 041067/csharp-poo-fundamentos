﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Upcasting_Downcasting
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Upcasting
            Funcionario meuFuncionario = new Funcionario("João", 2000);
            Pessoa minhaPessoa = meuFuncionario; // Upcasting implícito
            minhaPessoa.ImprimirNome();
            // Downcasting
            Pessoa outraPessoa = new Funcionario("Maria", 3000);
            Funcionario outroFuncionario = (Funcionario)outraPessoa; // Downcasting explícito
            outroFuncionario.ImprimirSalario();

            Console.ReadKey();
        }
    }
}
