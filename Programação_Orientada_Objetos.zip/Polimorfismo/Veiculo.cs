﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polimorfismo
{
    internal class Veiculo
    {
        // Métotodo virtual permite ser sobrescrito em classes derivadas (Polimorfirsmo)
        virtual public void Andar()
        {
            Console.WriteLine("O veículo está andando");
        }
    }
}
