﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Modificador static (estático ou fixo) - Ele é sempre usado após o modificador de acesso
//Pode ser usado em classes, métodos, propriedades, campos, eventos, construtores e strut ...

namespace Modificador_Static_e_Palavra_This
{
    // A classe Endereco possui propriedades static
    public class Endereco
    {
        private static string rua = "Rua 7 de setembro";
        public static string Rua
        {
            get { return rua; }
            set { rua = value; }
        }
        private static int numero = 234;
        public static int Numero
        {
            get { return numero; }
            set { numero = value; }
        }
        private static string bairro = "Tatuapé";
        public static string Bairro
        {
            get { return bairro; }
            set { bairro = value; }
        }
        private static string cidade = "São Paulo";
        public static string Cidade
        {
            get { return cidade; }
            set { cidade = value; }
        }
        private static string estado = "São Paulo";
        public static string Estado
        {
            get { return estado; }
            set { estado = value; }
        }
        private static string pais = "Brasil";
        public static string Pais
        {
            get { return pais; }
            set { pais = value; }
        }

        public Endereco(string pRua, int pNumero, string pBairro, string pCidade, string pEstado, string pPais)
        {
            rua = pRua;
            numero = pNumero;
            bairro = pBairro;
            cidade = pCidade;
            estado = pEstado;
            pais = pPais;
        }

        
    }
    // A classe Calculadora possui um método static
    public class Calculadora
    {
        public static double Pi = 3.14;
        public static double CalcularAreaCircunferencia(double pRaio)
        {
            return Pi * Math.Pow(pRaio, 2);
        }
    }
    // A classe Usuario possui campos static
    public class Usuario
    {
        public static double  Altura = 1.89;
        public static int Idade = 29;

    }
    // Palavra this
    public class Estado
    {
        public string Nome;
        public string Sigla;
        public Estado(string Nome, string Sigla)
        {
            // O this diferencia o campo da classe do parâmetro do construtor
            this.Nome = Nome;
            this.Sigla = Sigla;
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            //static não precisa ser instanciado, ou seja, é chamado diretamente pela classe
            Console.WriteLine("Você mora na rua: " + Endereco.Rua);
            Console.WriteLine("número: " + Endereco.Numero);
            Console.WriteLine("No bairro: " + Endereco.Bairro);
            Console.WriteLine("Cidade de : " + Endereco.Cidade);
            Console.WriteLine("Estado de: " + Endereco.Estado);
            Console.WriteLine("País: " + Endereco.Pais);
            

            Console.WriteLine("O valor de PI é: " + Calculadora.Pi);
            Console.WriteLine("A área é " + Calculadora.CalcularAreaCircunferencia(2));

            Console.WriteLine("Sua altura é de: " + Usuario.Altura);
            Console.WriteLine("Sua idade é de: " + Usuario.Idade);

            Console.ReadLine();
        }
    }
}