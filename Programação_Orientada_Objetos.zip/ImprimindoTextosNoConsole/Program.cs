﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImprimindoTextosNoConsole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            Console.WriteLine("");
            Imprime um texto no console e pula para a próxima linha.
            O Line já indica que ele quebra a linha depois da mensagem.
            Console.ReadKey();
            Espera o usuário pressionar Enter para finalizar
            Console.WriteLine("Olá Sesi Brotas");
            Console.WriteLine("Tudo bem?");
            Console.ReadKey();
            */

            /*
            Console.ReadLine();
            Lê o que o usuário digitar no console e só segue após apertar Enter.
            Retorna o texto digitado como string.
            Console.WriteLine("Digite seu nome:");
            string nome = Console.ReadLine();
            Console.WriteLine("Olá, " + nome);
            */

            /*
            Console.Write("");
            Imprime um texto sem pular para a próxima linha.
            Console.Write("Meu nome é ");
            Console.WriteLine("Sesi");
            Console.WriteLine("Brotas");
            Console.WriteLine("SP");
            Console.ReadKey();*/

            /*
            Console.WriteLine("\r\n");
            \r\n é um caractere especial de quebra de linha (padrão do Windows).
            Esse comando vai pular uma linha em branco no console.
            Console.WriteLine("Linha 1");
            Console.WriteLine("\r\n");
            Console.WriteLine("Linha 2");
            Console.ReadKey();*/
        }
    }
}