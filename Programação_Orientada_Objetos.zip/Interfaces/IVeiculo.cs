﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    internal interface IVeiculo
    {
        //METODO: Definir os membros da interface
        void Ligar();
        void Desligar();
        void AbrirPorta();
        void FecharPorta();
    }
}
