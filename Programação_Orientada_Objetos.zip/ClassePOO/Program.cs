﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassePOO
{
    public class Carro
    {
        // Atributos ou Variáveis
        private string modelo;
        private string marca;
        private UInt32 velocidade;
        private bool carroLigado;

        //Propriedades 
        public string Modelo
        {
            get { return modelo; } //Get é para ler o valor
            set { modelo = value; } //Set é para atribuir um valor
        }
        public string Marca
        {
            get { return marca; }
            set { marca = value; }
        }
        public UInt32 Velocidade
        {
            get { return velocidade; }
            set { velocidade = value; }
        }
        public bool CarroLigado
        {
            get { return carroLigado; }
            set { carroLigado = value; }
        }
        // Métodos ou Funções
        public void LigarCarro()
        {
            carroLigado = true;
            Console.WriteLine("Ligando carro da marca " + marca + " e do modelo " + modelo);
        }
        public void DesligandoCarro()
        {
            carroLigado = false;
            Console.WriteLine("Desligando o carro da marca " + marca + " e do modelo " + modelo);
        }
        public void AcelerarCarro(UInt32 velocidadeFinal)
        { 
            if (carroLigado == true)
            {
                velocidade = velocidadeFinal;
                Console.WriteLine("A velocidade do carro da marca " + marca + " e do modelo " + modelo + " é " + velocidadeFinal);
            }
            else
            {
                Console.WriteLine("O carro da marca " + marca + " e do modelo " + modelo + " esta desligado ");
            }
        }
        public void PararCarro()
        {
            if (velocidade == 0)
            {
                Console.WriteLine("O carro da marca " + marca + " já está parado ");
            }
            else 
            { 
                velocidade = 0;
                Console.WriteLine("O carro da marca " + marca + " está parado ");
            }
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Carro X6 = new Carro(); //Instanciando a classe Carro
            X6.Marca = "BMW";//Atribuindo valor a propriedade Marca
            X6.Modelo = "XDrive";
            X6.LigarCarro();
            X6.AcelerarCarro(200);
            X6.PararCarro();
            X6.DesligandoCarro();

            Carro corolla = new Carro();
            corolla.Marca = "Toyota";
            corolla.Modelo = "Corolla";
            corolla.LigarCarro();
            corolla.AcelerarCarro(180);
            corolla.PararCarro();
            corolla.DesligandoCarro();

            Console.ReadKey();
        }
    }
}
