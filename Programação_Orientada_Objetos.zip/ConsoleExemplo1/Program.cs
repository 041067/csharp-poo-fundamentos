﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleExemplo1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Olá Senai!"); // Console.WriteLine exibe uma mensagem no console
            Console.ReadLine(); // Console.ReadLine espera o usuário pressionar Enter para finalizar
            // Aqui dentro vai o código que será executado
        }
        // Esse é um comentário de linha única

        /* 
          Esse é um comentário
          de múltiplas linhas
          È importante comentar o código para facilitar a compreensão do que o código faz

        */
    }
}
