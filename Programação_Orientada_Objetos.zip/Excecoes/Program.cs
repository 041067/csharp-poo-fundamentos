﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excecoes
{
    internal class Marcos
    {
        public void ImprimirNome()
        {
            Console.WriteLine("Marcos");
        }
    }

    internal class Program
    {
        static Marcos marcos;
        static void Main(string[] args)
        {
            //Como forçar uma exceção
            try
            {
                Console.WriteLine("Digite um número positivo");
                int numero = Convert.ToInt32(Console.ReadLine());
                if (numero < 0)
                    throw new Exception("O número " + numero + " é negativo");
                else
                    Console.WriteLine("O número digitado é positivo");
            }
            catch (Exception e)
            {
                Console.WriteLine("Erro/Exceção: " + e.Message);
            }
            finally
            {
                Console.WriteLine("Digite qualquer tecla para sair");
                Console.ReadKey();
            }
            //Como forçar uma exceção
            try
            {
                Console.WriteLine("Digite um numerador");
                int numerador = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Digite um denominador");
                int denominador = Convert.ToInt32(Console.ReadLine());

                int resultado = numerador / denominador;

                Console.WriteLine("O resultado da divisão é " + resultado);

                marcos.ImprimirNome();
            }
            catch (DivideByZeroException e)
            {
                Console.WriteLine("Erro/Exceção de divisão por zero: " + e.Message);
            }
            catch (NullReferenceException e)
            {
                Console.WriteLine("Erro/Exceção de objeto nulo " + e.Message);
            }
            catch (Exception e) //bloco de execução generico
            {
                Console.WriteLine("Ocorreu um erro/exceção: " + e.Message);
            }
            finally //opcional
            {
                Console.WriteLine("Digite qualquer tecla para sair");
                Console.ReadKey();
            }
            
        }
    }
}
