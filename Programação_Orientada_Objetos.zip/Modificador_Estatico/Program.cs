﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Modificador static (estatico ou fixo) - Ele é sempre usado após o modificador de acesso
//Pode ser usado em classes, métodos, atributos, propriedades, etc

namespace Modificador_Estatico
{
    public class Endereço
    {
        //Atributos
        private static string rua = "Rua 7 setembro";
        public static string Rua
        {
            get { return rua; } //retorna o valor da variável
            set { rua = value; }//atribui um valor a variável
        }
        private static int numero = 234;
        public static int Numero
        {
            get { return numero; }
            set { numero = value; }
        }
        private static string bairro = "Tatuapé";
        public static string Bairro
        {
            get { return bairro; }
            set { bairro = value; }
        }
        private static string cidade = "São Paulo";
        public static string Cidade
        {
            get { return cidade; }
            set { cidade = value; }
        }
        private static string estado = "SP";
        public static string Estado
        {
            get { return estado; }
            set { estado = value; }
        }
        private static string pais = "Brasil";
        public static string Pais
        {
            get { return pais; }
            set { pais = value; }
        }
        //Construtor
        public Endereço(string pRua, int pNumero, string pBairro, string pCidade, string pEstado, string pPais)
        {
            rua = pRua;
            numero = pNumero;
            bairro = pBairro;
            cidade = pCidade;
            estado = pEstado;
            pais = pPais;
        }

    }
    public class Calculadora
    {
        public static double Pi = 3.14;
        public static double CalcularAreaCircunferencia(double pRaio)
        {
            return Pi * Math.Pow(pRaio, 2);
        }
    }
    public class Usuario
    {
        public static double Altura = 1.75;
        public static int Idade = 30;
    }
    //Uso da palavra this - Usada para referenciar o objeto atual da classe
    public class Estado
    {
        public string Nome;
        public string Sigla;
        public Estado(string Nome, string Sigla)
        {
            //O this diferencia o atributo do parâmetro
            this.Nome = Nome;
            this.Sigla = Sigla;
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            //Stactic não precisa ser instanciada, ou seja, é chamado diretamente pela classe
            Console.WriteLine("Você mora na rua: " + Endereço.Rua);
            Console.WriteLine("Número: " + Endereço.Numero);
            Console.WriteLine("No bairro: " + Endereço.Bairro);
            Console.WriteLine("Cidade de : " + Endereço.Cidade);
            Console.WriteLine("Estado de: " + Endereço.Estado);
            Console.WriteLine("País: " + Endereço.Pais);

            Console.WriteLine("O valor de PI é: " + Calculadora.Pi);
            Console.WriteLine("A área é " + Calculadora.CalcularAreaCircunferencia(2));

            Console.WriteLine("A sua altura é: " + Usuario.Altura);
            Console.WriteLine("A sua idade é: " + Usuario.Idade);

            Console.ReadKey();
        }
    }
}
