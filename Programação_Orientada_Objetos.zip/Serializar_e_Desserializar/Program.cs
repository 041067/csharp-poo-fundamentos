﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml; // Necessário para trabalhar com XML
using System.IO; // Necessário para trabalhar com arquivos
using System.Runtime.Serialization; 

namespace Serializar_e_Desserializar
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Cachorro meuCachorro = new Cachorro("Rex", "Pastor Alemão", "Preto e Marrom");
            Cachorro meuCachorroDesserializado;

            DataContractSerializer serializador = new DataContractSerializer(typeof(Cachorro));

            // Serialização
            XmlWriterSettings xmlConfig = new XmlWriterSettings { Indent = true };
            StringBuilder construtorDeString = new StringBuilder();
            XmlWriter escritorXML = XmlWriter.Create(construtorDeString, xmlConfig);
            serializador.WriteObject(escritorXML, meuCachorro);
            escritorXML.Flush();
            string objetoSerializadorStr = construtorDeString.ToString();

            // Salvando o arquivo XML
            string caminhoDoArquivoXML = "Cachorro.xml";
            FileStream meuArquivoXML = File.Create(caminhoDoArquivoXML);
            meuArquivoXML.Close();
            File.WriteAllText(caminhoDoArquivoXML, objetoSerializadorStr);

            // Desserialização
            string conteudoDoObjetoSerializado = File.ReadAllText(caminhoDoArquivoXML);
            StringReader leitorDeString = new StringReader(conteudoDoObjetoSerializado);
            XmlReader leitorXML = XmlReader.Create(leitorDeString);
            meuCachorroDesserializado = (Cachorro)serializador.ReadObject(leitorXML);

            leitorDeString.Close();
            leitorXML.Close();
        }
    }
}
