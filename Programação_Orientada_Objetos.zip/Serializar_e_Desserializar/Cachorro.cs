﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;// Necessário para serialização e desserialização

namespace Serializar_e_Desserializar
{
    [DataContract] // Indica que a classe pode ser serializada
    internal class Cachorro
    {
        [DataMember] // Indica que o campo pode ser serializado
        public string Nome { get; set; }
        [DataMember]
        public string raca;
        [DataMember]
        private string cor;
        public Cachorro(string pNome, string pRaca, string pCor)
        {
            Nome = pNome;
            raca = pRaca;
            cor = pCor;
        }
        public Cachorro()
        {

        }
    }
}
